import random
import argparse
import re
import math

class Process:
    def __init__(self, A, B, C, M):
        self.arrival_time = A #arrival time of the process
        self.next_burst_time = B #calculate next CPU burst time
        self.total_CPU_time = C #remaining CPU time
        self.IO_burst_time = M #calculate the next I/O burst time
        self.state = 0 # the state of the process: 0 is unstarted, 1 is ready, 2 is running, 3 is blocked, 4 is terminated
        self.IO_time = 0 # I/O running time
        self.finish_time = 0 # time when the process finishes
        self.real_total_CPU = C # total CPU time
        self.waiting_time = 0 # process waiting time when ready
        self.ready_cycle = 0 # the time when the process becomes ready
        self.real_burst_original = 0 # the calculated CPU burst time for this process

    def get_arrival_time(self):
        return self.arrival_time

    def change_state(self, state):
        self.state = state

    def get_state(self):
        return self.state

    def get_next_burst_time(self):
        return self.next_burst_time

    def set_total_CPU_time(self, t):
        self.total_CPU_time = t

    def get_total_CPU_time(self):
        return self.total_CPU_time

    def decrease_cycle(self):
        self.total_CPU_time = self.total_CPU_time-1

    def increase_IO_time(self):
        self.IO_time += 1

    def set_IO_time(self, t):
        self.IO_time = t

    def get_IO_burst_time(self):
        return self.IO_burst_time
    
    def set_finish_time(self, f_time):
        self.finish_time = f_time
    
    def get_real_total_CPU(self):
        return self.real_total_CPU

    def increase_waiting_time(self):
        self.waiting_time+=1
    
    def get_finish_time(self):
        return self.finish_time

    def get_IO_time(self):
        return self.IO_time
    
    def get_waiting_time(self):
        return self.waiting_time

    def set_ready_cycle(self, c):
        self.ready_cycle = c

    def get_ready_cycle(self):
        return self.ready_cycle

    def set_real_burst_original(self, rbo):
        self.real_burst_original = rbo
    
    def get_real_burst_original(self):
        return self.real_burst_original

    def set_wait_time(self, t):
        self.waiting_time = t

#theFile = open("/Users/javierxu/Desktop/random-numbers.txt", "r") # read and use the random numbers file
theFile = open("random-numbers.txt", "r")

theInts = []
for val in theFile.read().split(): # store random numbers in a list
    theInts.append(int(val))
theFile.close()

def randomOS(index, burst): # calculate the next CPU burst time using the random number
    val = 1 + theInts[index] % burst
    return val

parser = argparse.ArgumentParser(description='Scheduling') # deal with input command
parser.add_argument('--verbose', action="store_true", default=False)
parser.add_argument('input', type=str)
args = parser.parse_args()

process_input = open(args.input, "r") # read input file
processfile = []
process = dict()
for val in process_input.read().split():
    processfile.append(int(val))
process_input.close()

#print initial input
num_of_process = processfile[0]
print("The original input was: " + str(num_of_process), end = " ")
i = 1
n=0
while(i<len(processfile)):
    process[n] = [processfile[i],processfile[i+1],processfile[i+2],processfile[i+3]]
    print(" "+ str(processfile[i])+" "+str(processfile[i+1])+" "+str(processfile[i+2])+" "+str(processfile[i+3]), end = " ")
    i = i+4
    n = n+1
print("\n")

#sort by arrival time
def sort_arrival_time(pr):
    return pr.arrival_time

#print sorted input
process_list = []
for i in range(len(process)):
    process_list.append(Process(process[i][0], process[i][1], process[i][2], process[i][3]))
process_list= sorted(process_list, key= sort_arrival_time)
print("The (sorted) input is: "+ str(num_of_process),end = " ")
for i in process_list:
    print(" "+ str(i.get_arrival_time()) + " "+ str(i.get_next_burst_time())+ " "+str(i.get_total_CPU_time())+" "+str(i.get_IO_burst_time()), end = " ")
print("\n")

# first come first serve
def FCFS():
    index = 0 # index of the random numbers file
    next_burst = 0 # the next cpu burst
    next_burst_original = 0 # preceding cpu burst
    finished = False
    P_time = 0 # process time
    ready = [] # list of processes that are ready
    running = None #the running process
    blocked = [-1]*len(process_list) #the blocked process
    CPU_Util = 0.000000 #the CPU Utility
    IO_Util = 0.000000 # the I/O Untility
    Num_finished = 0 #the number of finished process

    
    if args.verbose:
        print("This detailed printout gives the state and remaining burst for each process")

    while finished == False:
        
        if args.verbose:
            print("Before cycle " + str(P_time)+ ": ", end = " ")
            for p in process_list:
                if p.get_state() == 0:
                    print("unstarted 0 ", end = " ")
                elif p.get_state() == 1:
                    print("ready 0 ", end = " ")
                elif p.get_state() == 2:
                    print("running "+str(next_burst), end = " ")
                elif p.get_state() == 3:
                    print("blocked "+ str(blocked[process_list.index(p)]), end = " ")
                elif p.get_state() == 4:
                    print("terminated 0 ", end =" ")
            print("\n")

        for i in range(len(blocked)):
            if blocked[i]>0:
                blocked[i]-=1
                process_list[i].increase_IO_time() # I/O running
                if blocked[i] == 0: # I/O time finishes, the process is no longer blocked, enter ready state
                    ready.append(process_list[i]) 
                    blocked[i] = -1
                    process_list[i].change_state(1)

        for p in process_list: # process arrival time is current time, enter ready state
            if p.get_arrival_time() == P_time:
                ready.append(p)
                p.change_state(1)
        
                
        if running == None and len(ready) != 0: 
            # if no process is running, and there are processes ready, 
            # select the first one to run (first come first serve)
            running = ready[0] 
            process_list[process_list.index(running)].change_state(2)
            next_burst = randomOS(index,running.get_next_burst_time())
            next_burst_original = randomOS(index,running.get_next_burst_time())
            index += 1
            ready.pop(0)
        
        elif running != None:
            # if there is process running, reduce the process total CPU time by 1, 
            #  reduce the CPU burst time by 1, increase the CPU utility by 1, 
            process_list[process_list.index(running)].decrease_cycle()
            next_burst -= 1
            CPU_Util += 1

            # if there is still CPU burst time remaining, but no total CPU time remaining, 
            # terminate the process and select a new process to run from ready list
            if next_burst > 0 and running.get_total_CPU_time() == 0:
                running.set_finish_time(P_time)
                process_list[process_list.index(running)].change_state(4)
                Num_finished += 1
                running = None
                if len(ready) != 0:
                    running = ready[0]
                    process_list[process_list.index(running)].change_state(2)
                    ready.pop(0)
                    next_burst = randomOS(index, running.get_next_burst_time())
                    next_burst_original = randomOS(index,running.get_next_burst_time())
                    index += 1
                else:
                    running = None
            
            
            elif next_burst == 0:
                #if there is no CPU burst time remaining, but still CPU total time remaining,
                #the running process is blocked for I/O burst time and select a new process to run
                if(running.get_total_CPU_time()>0):
                    process_list[process_list.index(running)].change_state(3)
                    blocked[process_list.index(running)] = next_burst_original*running.get_IO_burst_time()
                    running = None

                #if there is no CPU burst time remaining, nor CPU total time remaining, 
                # the running process is terminated and select a new process to run
                else:
                    running.set_finish_time(P_time)
                    process_list[process_list.index(running)].change_state(4)
                    Num_finished += 1
                    running = None
                if len(ready) != 0:
                    running = ready[0]
                    process_list[process_list.index(running)].change_state(2)
                    ready.pop(0)
                    next_burst = randomOS(index, running.get_next_burst_time())
                    next_burst_original = randomOS(index,running.get_next_burst_time())
                    index += 1
                else:
                    running = None

        for p in ready: # increase waiting time for ready process
            p.increase_waiting_time()    

        if Num_finished == len(process_list): # increase finished process
            finished = True

        for i in range(len(blocked)): # if the process is blocked, increase I/O utility
            if blocked[i]>0:
                IO_Util+=1
                break

        P_time += 1 # increase cycle
    print("\n")
    print("The scheduling algorithm used was First Come First Served")
    print("\n")
    average_waiting_time = 0.000000
    average_turnaround_time = 0.000000
    final_time = 0
    for p in process_list:
        print("Process " + str(process_list.index(p)) + ":")
        print("(A,B,C,M) = (" + str(p.get_arrival_time())+"," + str(p.get_next_burst_time())+","+str(p.get_real_total_CPU())+","+str(p.get_IO_burst_time())+")")
        print("Finishing time: " + str(p.get_finish_time()))
        if p.get_finish_time() > final_time:
            final_time = p.get_finish_time()
        print("Turnaround time: " + str(p.get_finish_time()-int(p.get_arrival_time())))
        average_turnaround_time += p.get_finish_time()-int(p.get_arrival_time())
        print("I/O time: " + str(p.get_IO_time()))
        print("Waiting time: " + str(p.get_waiting_time())+"\n")
        average_waiting_time += p.get_waiting_time()
    print("\n")
    print("Summary Data:")
    print("Finishing time: " + str(final_time))
    print("CPU Utilization: " + str(float(CPU_Util/final_time)))
    print("IO Utilization: " + str(IO_Util/final_time))
    print("Throughput: " + str((len(process_list)/final_time)*100)+ " processes per hundred cycles")
    print("Average turnaround time: " + str(average_turnaround_time/len(process_list)))
    print("Average waiting time: " + str(average_waiting_time/len(process_list)))
    print("\n")


def RR():
    CPU_burst = 0
    index = 0
    quantum = 2
    next_burst = 0 # the calculated CPU burst using B compared with quantum, select the smaller one
    next_burst_original = 0
    finished = False
    P_time = 0
    ready = []
    blocked = [-1]*len(process_list)
    CPUtime = [0]*len(process_list) #the CPU burst calculated using B, stored in a list
    CPU_Util = 0.000000
    IO_Util = 0.000000
    running = None
    Num_finished = 0
    if args.verbose:
        print("This detailed printout gives the state and remaining burst for each process")

    while finished == False:
        if(args.verbose):
            print("Before cycle " + str(P_time)+ ": ", end = " ")
            for p in process_list:
                if p.get_state() == 0:
                    print("unstarted 0 ", end = " ")
                elif p.get_state() == 1:
                    print("ready 0 ", end = " ")
                elif p.get_state() == 2:
                    print("running "+str(next_burst), end  = " ")
                elif p.get_state() == 3:
                    print("blocked "+ str(blocked[process_list.index(p)]), end  = " ")
                elif p.get_state() == 4:
                    print("terminated 0 ", end =" ")
            print("\n")

        for i in range(len(blocked)): 
            # same with FCFS, except here we record the time when the process becomes ready, 
            # so that it is easier for us to sort them later
            if blocked[i] > 0:
                blocked[i] -= 1
                process_list[i].increase_IO_time()
                if blocked[i] == 0:
                    ready.append(process_list[i])
                    process_list[i].set_ready_cycle(P_time)
                    blocked[i] = -1
                    process_list[i].change_state(1)
        
        for p in process_list:
            if p.get_arrival_time() == P_time:
                ready.append(p)
                p.change_state(1)
                p.set_ready_cycle(P_time)
        
        if running == None and (len(ready)!=0):
            ready_cycle = math.inf
            arrival = math.inf
            process_index = math.inf

            # find the process that becomes ready at the earliest time; if ready at the same time, 
            # select the process with the earliest arrival time; if arrival time the same, 
            # select the one with the smallest index in the process list
            for p in ready:
                if p.get_ready_cycle()<ready_cycle:
                    ready_cycle = p.get_ready_cycle()
                    arrival = p.get_arrival_time()
                    process_index = process_list.index(p)
                    running = p
                elif p.get_ready_cycle()== ready_cycle:
                    if p.get_arrival_time()<arrival:
                        arrival = p.get_arrival_time()
                        process_index = process_list.index(p)
                        running = p
                    elif p.get_arrival_time()==arrival:
                        if process_list.index(p) < process_index:
                            process_index = process_list.index(p)
                            running = p
            process_list[process_list.index(running)].change_state(2)
            CPU_burst = randomOS(index, running.get_next_burst_time())
            next_burst_original = randomOS(index, running.get_next_burst_time())
            process_list[process_list.index(running)].set_real_burst_original(next_burst_original)
            index += 1
            CPUtime[process_list.index(running)] = CPU_burst

            #compare the calculate CPU_burst time with quantum and choose the smaller one
            if CPU_burst > quantum:
                next_burst = quantum
            else:
                next_burst = CPU_burst
            ready.pop(ready.index(running))

        elif running != None:

            process_list[process_list.index(running)].decrease_cycle()
            next_burst -= 1
            CPUtime[process_list.index(running)] -= 1
            CPU_Util += 1

            if next_burst>0 and running.get_total_CPU_time()==0:
                running.set_finish_time(P_time)
                process_list[process_list.index(running)].change_state(4)
                Num_finished += 1
                running = None
                if len(ready) != 0:
                    ready_cycle = math.inf
                    arrival = math.inf
                    for p in ready:
                        if p.get_ready_cycle()<ready_cycle:
                            ready_cycle = p.get_ready_cycle()
                            arrival = p.get_arrival_time()
                            process_index = process_list.index(p)
                            running = p
                        elif p.get_ready_cycle()== ready_cycle:
                            if p.get_arrival_time()<arrival:
                                arrival = p.get_arrival_time()
                                process_index = process_list.index(p)
                                running = p
                            elif p.get_ready_cycle()== ready_cycle and p.get_arrival_time()==arrival:
                                if process_list.index(p) < process_index:
                                    process_index = process_list.index(p)
                                    running = p
                    process_list[process_list.index(running)].change_state(2)

                    #decide the CPU burst time: if there is still CPU burst remaining from last running
                    #use the remaining time, otherwise, calculate the new CPU burst time
                    if CPUtime[process_list.index(running)] > 0:
                        CPU_burst = CPUtime[process_list.index(running)]
                        next_burst_original = running.get_real_burst_original()
                    else:
                        CPU_burst = randomOS(index, running.get_next_burst_time())
                        next_burst_original = randomOS(index, running.get_next_burst_time())
                        process_list[process_list.index(running)].set_real_burst_original(next_burst_original)
                        index += 1
                    CPUtime[process_list.index(running)] = CPU_burst
                    if CPU_burst > quantum:
                        next_burst = quantum
                    else:
                        next_burst = CPU_burst
                    ready.pop(ready.index(running))


            elif next_burst == 0:
                if running.get_total_CPU_time()>0 and CPUtime[process_list.index(running)]>0: 
                    #running process preempted, enter ready state
                    process_list[process_list.index(running)].change_state(1)
                    ready.append(running)
                    process_list[process_list.index(running)].set_ready_cycle(P_time)
                    running = None

                elif running.get_total_CPU_time()>0 and CPUtime[process_list.index(running)] == 0:
                    #running process blocked
                    process_list[process_list.index(running)].change_state(3)
                    blocked[process_list.index(running)] = next_burst_original*running.get_IO_burst_time()
                    running = None

                elif running.get_total_CPU_time()==0:
                    #running process terminated
                    running.set_finish_time(P_time)
                    process_list[process_list.index(running)].change_state(4)
                    Num_finished += 1
                    running = None
                     
                if len(ready)!= 0:
                    #select new process
                    ready_cycle = math.inf
                    arrival = math.inf
                    process_index = math.inf
                    for p in ready:
                        if p.get_ready_cycle()<ready_cycle:
                            ready_cycle = p.get_ready_cycle()
                            arrival = p.get_arrival_time()
                            process_index = process_list.index(p)
                            running = p
                        elif p.get_ready_cycle()== ready_cycle:
                            if p.get_arrival_time()<arrival:
                                arrival = p.get_arrival_time()
                                process_index = process_list.index(p)
                                running = p
                            elif p.get_ready_cycle()== ready_cycle and p.get_arrival_time()==arrival:
                                if process_list.index(p) < process_index:
                                    process_index = process_list.index(p)
                                    running = p
                    process_list[process_list.index(running)].change_state(2)
                    if CPUtime[process_list.index(running)] > 0:
                        CPU_burst = CPUtime[process_list.index(running)]
                        next_burst_original = running.get_real_burst_original()
                    else:
                        CPU_burst = randomOS(index, running.get_next_burst_time())
                        next_burst_original = randomOS(index, running.get_next_burst_time())
                        process_list[process_list.index(running)].set_real_burst_original(next_burst_original)
                        index += 1
                    CPUtime[process_list.index(running)] = CPU_burst
                    if CPU_burst > quantum:
                        next_burst = quantum
                    else:
                        next_burst = CPU_burst
                    ready.pop(ready.index(running))
                else:
                    running = None
        
        for p in ready:
            p.increase_waiting_time()
        
        if Num_finished == len(process_list):
            finished = True

        for i in range(len(blocked)):
            if blocked[i]>0:
                IO_Util+=1
                break
    
        P_time += 1

    print("The scheduling algorithm used was Round Robbin")
    print("\n")
    average_waiting_time = 0.000000
    average_turnaround_time = 0.000000
    final_time = 0
    for p in process_list:
        print("Process " + str(process_list.index(p)) + ": ")
        print("(A,B,C,M) = (" + str(p.get_arrival_time())+"," + str(p.get_next_burst_time())+","+str(p.get_real_total_CPU())+","+str(p.get_IO_burst_time())+ ")")
        print("Finishing time: " + str(p.get_finish_time()) )
        if p.get_finish_time() > final_time:
            final_time = p.get_finish_time()
        print("Turnaround time: " + str(p.get_finish_time()-p.get_arrival_time()))
        average_turnaround_time += p.get_finish_time()-p.get_arrival_time()
        print("I/O time: " + str(p.get_IO_time()) )
        print("Waiting time: " + str(p.get_waiting_time()))
        average_waiting_time += p.get_waiting_time()
    print("\n")
    print("Summary Data: ")
    print("Finishing time: " + str(final_time) )
    print("CPU Utilization: " + str(CPU_Util/final_time))
    print("IO Utilization: " + str(IO_Util/final_time) )
    print("Throughput: " + str((len(process_list)/final_time)*100)+ " processes per hundred cycles")
    print("Average turnaround time: " + str(average_turnaround_time/len(process_list)))
    print("Average waiting time: " + str(average_waiting_time/len(process_list)))
    print("\n")

def SJF():
    index = 0
    next_burst = 0
    finished = False
    P_time = 0
    ready = []
    blocked = [-1]*len(process_list)
    CPU_Util = 0.000000
    IO_Util = 0.000000
    running = None
    Num_finished = 0

    if args.verbose:
        print("This detailed printout gives the state and remaining burst for each process")

    while finished == False:
        if(args.verbose):
            print("Before cycle " + str(P_time)+ ": ", end =" ")
            for p in process_list:
                if p.get_state() == 0:
                    print("unstarted 0 ", end = " ")
                elif p.get_state() == 1:
                    print("ready 0 ", end  = " ")
                elif p.get_state() == 2:
                    print("running "+str(next_burst), end = " ")
                elif p.get_state() == 3:
                    print("blocked "+ str(blocked[process_list.index(p)]), end =" ")
                elif p.get_state() == 4:
                    print("terminated 0 ", end =" ")
            print("\n")

        for i in range(len(blocked)):
            if blocked[i]>0:
                blocked[i] -= 1
                process_list[i].increase_IO_time()
                if blocked[i] == 0:
                    ready.append(process_list[i])
                    blocked[i] = -1
                    process_list[i].change_state(1)

        for p in process_list:
            if(p.get_arrival_time()==P_time):
                ready.append(p)
                p.change_state(1)
        
        
        if running == None and (len(ready)!= 0):
            #choose the process with the minimum remaining time
            min_remaining_time = math.inf
            for p in ready:
                if p.get_total_CPU_time()<min_remaining_time:
                    running = p
                    min_remaining_time = p.get_total_CPU_time()
            process_list[process_list.index(running)].change_state(2)
            next_burst = randomOS(index, running.get_next_burst_time())
            next_burst_original = randomOS(index, running.get_next_burst_time())
            index += 1
            ready.pop(ready.index(running))
            
        elif running != None:
            process_list[process_list.index(running)].decrease_cycle()
            CPU_Util += 1
            next_burst -= 1

            if next_burst > 0 and running.get_total_CPU_time()==0:
                running.set_finish_time(P_time)
                process_list[process_list.index(running)].change_state(4)
                Num_finished += 1
                running = None
                if len(ready) != 0:
                    min_remaining_time = math.inf
                    for p in ready:
                        if p.get_total_CPU_time()<min_remaining_time:
                            running = p
                            min_remaining_time = p.get_total_CPU_time()
                    process_list[process_list.index(running)].change_state(2)
                    next_burst = randomOS(index, running.get_next_burst_time())
                    next_burst_original = randomOS(index, running.get_next_burst_time())
                    index += 1
                    ready.pop(ready.index(running))

            elif next_burst == 0:
                if running.get_total_CPU_time() > 0:
                    process_list[process_list.index(running)].change_state(3)
                    blocked[process_list.index(running)] = next_burst_original*running.get_IO_burst_time()
                    running = None
                else:
                    running.set_finish_time(P_time)
                    process_list[process_list.index(running)].change_state(4)
                    Num_finished += 1
                    running = None
                if len(ready) != 0:
                    min_remaining_time = math.inf
                    for p in ready:
                        if p.get_total_CPU_time()<min_remaining_time:
                            running = p
                            min_remaining_time = p.get_total_CPU_time()
                    process_list[process_list.index(running)].change_state(2)
                    next_burst = randomOS(index, running.get_next_burst_time())
                    next_burst_original = randomOS(index, running.get_next_burst_time())
                    index += 1
                    ready.pop(ready.index(running))
                else:
                    running = None

        for p in ready:
            p.increase_waiting_time()
        
        if Num_finished == len(process_list):
            finished = True

        for i in range(len(blocked)):
            if blocked[i]>0:
                IO_Util+=1
                break
        
        P_time+=1
    print("\n")
    print("The scheduling algorithm used was Shortest Job First")
    print("\n")
    average_waiting_time = 0.000000
    average_turnaround_time = 0.000000
    final_time = 0
    for p in process_list:
        print("Process " + str(process_list.index(p)) + ": ")
        print("(A,B,C,M) = (" + str(p.get_arrival_time())+"," + str(p.get_next_burst_time())+","+str(p.get_real_total_CPU())+","+str(p.get_IO_burst_time())+ ")")
        print("Finishing time: " + str(p.get_finish_time()))
        if p.get_finish_time() > final_time:
            final_time = p.get_finish_time()
        print("Turnaround time: " + str(p.get_finish_time()-p.get_arrival_time()))
        average_turnaround_time += p.get_finish_time()-p.get_arrival_time()
        print("I/O time: " + str(p.get_IO_time()) )
        print("Waiting time: " + str(p.get_waiting_time()))
        average_waiting_time += p.get_waiting_time()
    print("\n")
    print("Summary Data:")
    print("Finishing time: " + str(final_time) )
    print("CPU Utilization: " + str(float(CPU_Util/final_time)))
    print("IO Utilization: " + str(IO_Util/final_time))
    print("Throughput: " + str((len(process_list)/final_time)*100)+ " processes per hundred cycles")
    print("Average turnaround time: " + str(average_turnaround_time/len(process_list)))
    print("Average waiting time: " + str(average_waiting_time/len(process_list)))
    print("\n")


def HPRN():
    index = 0
    next_burst = 0
    next_burst_original = 0
    finished = False
    P_time = 0
    ready = []
    blocked = [-1]*len(process_list)
    CPU_Util = 0.000000
    IO_Util = 0.000000
    running = None
    Num_finished = 0

    if args.verbose:
        print("This detailed printout gives the state and remaining burst for each process")

    while finished == False:
        if(args.verbose):
            print("Before cycle " + str(P_time)+ ": ", end = " ")
            for p in process_list:
                if p.get_state() == 0:
                    print("unstarted 0 ", end = " ")
                elif p.get_state() == 1:
                    print("ready 0 ", end  =" ")
                elif p.get_state() == 2:
                    print("running "+str(next_burst), end= " ")
                elif p.get_state() == 3:
                    print("blocked "+ str(blocked[process_list.index(p)]), end = " ")
                elif p.get_state() == 4:
                    print("terminated 0 ", end = " ")
            print("\n")

        for i in range(len(blocked)):
            if blocked[i]>0:
                blocked[i] -= 1
                process_list[i].increase_IO_time()
                if blocked[i] == 0:
                    ready.append(process_list[i])
                    blocked[i] = -1
                    process_list[i].change_state(1)

        for p in process_list:
            if p.get_arrival_time()==P_time:
                ready.append(p)
                p.change_state(1)
        
        
        if running == None and len(ready) != 0:
            Highest_ratio = -math.inf
            new_ratio = None
            for p in ready:
                #select the one with the HIGHEST penalty ratio, 
                # and if the process running time is 0, select 1 to be the denominator
                new_ratio = (P_time - p.get_arrival_time())/max(1, p.get_real_total_CPU()-p.get_total_CPU_time())
                if new_ratio > Highest_ratio:
                    running = p
                    Highest_ratio = new_ratio
            process_list[process_list.index(running)].change_state(2)
            next_burst = randomOS(index, running.get_next_burst_time())
            next_burst_original = randomOS(index, running.get_next_burst_time())
            index += 1
            ready.pop(ready.index(running))

        elif running != None:
            process_list[process_list.index(running)].decrease_cycle()
            CPU_Util += 1
            next_burst -= 1

            if next_burst > 0 and running.get_total_CPU_time() == 0:
                running.set_finish_time(P_time)
                process_list[process_list.index(running)].change_state(4)
                Num_finished += 1
                running = None

                if len(ready) != 0:
                    Highest_ratio = -math.inf
                    new_ratio = None
                    for p in ready:
                        new_ratio = (P_time - p.get_arrival_time())/max(1, p.get_real_total_CPU()-p.get_total_CPU_time())
                        if new_ratio > Highest_ratio:
                            running = p
                            Highest_ratio = new_ratio
                    process_list[process_list.index(running)].change_state(2)
                    next_burst = randomOS(index, running.get_next_burst_time())
                    next_burst_original = randomOS(index, running.get_next_burst_time())
                    index += 1
                    ready.pop(ready.index(running))

            elif next_burst == 0:
                if running.get_total_CPU_time() >0:
                    process_list[process_list.index(running)].change_state(3)
                    blocked[process_list.index(running)] = next_burst_original*running.get_IO_burst_time()
                    running = None
                else: 
                    running.set_finish_time(P_time)
                    process_list[process_list.index(running)].change_state(4)
                    Num_finished += 1
                    running = None

                if len(ready) != 0:
                    Highest_ratio = -math.inf
                    new_ratio = None
                    for p in ready:
                        new_ratio = (P_time - p.get_arrival_time())/max(1, p.get_real_total_CPU()-p.get_total_CPU_time())
                        if new_ratio > Highest_ratio:
                            running = p
                            Highest_ratio = new_ratio
                    process_list[process_list.index(running)].change_state(2)
                    next_burst = randomOS(index, running.get_next_burst_time())
                    next_burst_original = randomOS(index, running.get_next_burst_time())
                    index += 1
                    ready.pop(ready.index(running))
                else: 
                    running = None

        for p in ready:
            p.increase_waiting_time()
        
        if Num_finished == len(process_list):
            finished = True

        for i in range(len(blocked)):
            if blocked[i]>0:
                IO_Util += 1
                break

        P_time += 1
    print("The scheduling algorithm used was ighest Penalty Ratio Next")
    print("\n")
    average_waiting_time = 0.000000
    average_turnaround_time = 0.000000
    final_time = 0
    for p in process_list:
        print("Process " + str(process_list.index(p)) + ": ")
        print("(A,B,C,M) = (" + str(p.get_arrival_time())+"," + str(p.get_next_burst_time())+","+str(p.get_real_total_CPU())+","+str(p.get_IO_burst_time())+ ")")
        print("Finishing time: " + str(p.get_finish_time()))
        if p.get_finish_time() > final_time:
            final_time = p.get_finish_time()
        print("Turnaround time: " + str(p.get_finish_time()-p.get_arrival_time()))
        average_turnaround_time += p.get_finish_time()-p.get_arrival_time()
        print("I/O time: " + str(p.get_IO_time()))
        print("Waiting time: " + str(p.get_waiting_time()))
        average_waiting_time += p.get_waiting_time()
    print("\n")
    print("Summary Data: ")
    print("Finishing time: " + str(final_time) )
    print("CPU Utilization: " + str(CPU_Util/final_time))
    print("IO Utilization: " + str(IO_Util/final_time))
    print("Throughput: " + str((len(process_list)/final_time)*100)+ " processes per hundred cycles ")
    print("Average turnaround time: " + str(average_turnaround_time/len(process_list)))
    print("Average waiting time: " + str(average_waiting_time/len(process_list)))
    print("\n")

FCFS()

#reset everything in process list
for p in process_list:
    p.set_total_CPU_time(p.get_real_total_CPU())
    p.change_state(0)
    p.set_IO_time(0)
    p.set_finish_time(0)
    p.set_wait_time(0)
    p.set_ready_cycle(0)
    p.set_real_burst_original(0)
RR()


for p in process_list:
    p.set_total_CPU_time(p.get_real_total_CPU())
    p.change_state(0)
    p.set_IO_time(0)
    p.set_finish_time(0)
    p.set_wait_time(0)
    p.set_ready_cycle(0)
    p.set_real_burst_original(0)
SJF()


for p in process_list:
    p.set_total_CPU_time(p.get_real_total_CPU())
    p.change_state(0)
    p.set_IO_time(0)
    p.set_finish_time(0)
    p.set_wait_time(0)
    p.set_ready_cycle(0)
    p.set_real_burst_original(0)
HPRN()